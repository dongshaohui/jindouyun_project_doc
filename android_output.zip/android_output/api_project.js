define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-03-30T11:44:09.223Z",
    "url": "http://apidocjs.com",
    "version": "0.15.1"
  }
});
